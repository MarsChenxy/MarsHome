package com.mars.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mars.model.Room;
import com.mars.service.RoomService;

@Controller
@RequestMapping("/room")
public class ChatRoomController {
	@Autowired
	RoomService roomService;
	@RequestMapping("/in")
	public @ResponseBody String menmberIn(HttpServletRequest request,HttpServletResponse response){
		String roomid=request.getParameter("roomid");
		String roomname=request.getParameter("roomname");
		String time=request.getParameter("time");
		int mapRoomCount=roomService.getRoomCountFromId(roomid);
		if(mapRoomCount==0){
			roomService.addNewRoom(roomid, roomname, 1,time);
		}else{
			roomService.addRoomMember(roomid);
		}

		return "Success";
	}
	@RequestMapping("/leave")
	public String memberLeave(HttpServletRequest request,HttpServletResponse response){
		String roomid=request.getParameter("roomid");
		int count=roomService.getRoomMemberCount(roomid);
		if(count<=1){
			roomService.delRoom(roomid);
		}else{
			roomService.delRoomMember(roomid);
		}
		return "Success";
	}
	@RequestMapping(value="/getJson",produces="text/html;charset=UTF-8")
	public @ResponseBody String jsonList(HttpServletRequest request,HttpServletResponse response){
		int page=Integer.parseInt(request.getParameter("page"));
		int rows=Integer.parseInt(request.getParameter("rows"));
		int total=roomService.getRoomCount();
		int totalPage=0;
		if(total%rows==0){
			 totalPage=total/rows;
		}else{
			 totalPage=total/rows+1;
		}
		int startRows=rows*(page-1);
		List<Room> list=roomService.getRoomList(startRows,rows);
		int i=0;
		String json="{\"page\":"+page+","
				+ "\"total\":"+totalPage+","
				+ "\"records\":"+total+","
				+ "\"rows\":[";
		for(Room room:list){
			i++;
			json+= "{\"id\":"+i+",\"cell\":[\""+room.getRoomid()+"\",\""+room.getRoomname()+"\",\""+room.getCount()+"\",\""+room.getCreatetime()+"\",null]},";
		}
		if(total!=0){
		 json = json.substring(0,json.length()-1);
		}
		 json+="],";
		 json+="\"userdata\":{\"amount\":200,\"tax\":342,\"total\":3564,\"name\":\"Totals\"}}";
		return json;
	}
	@RequestMapping(value="/getBootStrapTableJson",produces="text/html;charset=UTF-8")
	public @ResponseBody String getBootStrapTableJson(HttpServletRequest request,HttpServletResponse response){
		int page=Integer.parseInt(request.getParameter("pageNumber"));
		int rows=Integer.parseInt(request.getParameter("limit"));
		int total=roomService.getRoomCount();
		int totalPage=0;
		if(total%rows==0){
			totalPage=total/rows;
		}else{
			totalPage=total/rows+1;
		}
		int startRows=rows*(page-1);
		String json="{\"total\":"+total+",\"rows\":[";
		List<Room> list=roomService.getRoomList(startRows,rows);
		for(Room room:list){
			json+="{\"roomid\":\""+room.getRoomid()+"\",\"roomname\":\""+room.getRoomname()+"\",\"count\":\""+room.getCount()+"\",\"time\":\""+room.getCreatetime()+"\",\"operation\":\"\"},";
		}
		if(total!=0){
			json = json.substring(0,json.length()-1);
		}
		json+="]}";
		return json;
	}
}
