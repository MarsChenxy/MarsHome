package com.mars.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sound.sampled.AudioFormat.Encoding;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mars.model.Document;
import com.mars.model.Message;
import com.mars.model.Room;
import com.mars.service.DocumentService;

@Controller
@RequestMapping("/document")
public class DocumentController {
	@Autowired
	DocumentService documentService;
	@RequestMapping(value="/getJson",produces="text/html;charset=UTF-8")
	public @ResponseBody String jsonList(HttpServletRequest request,HttpServletResponse response){
		int page=Integer.parseInt(request.getParameter("page"));
		int rows=Integer.parseInt(request.getParameter("rows"));
		int total=documentService.getDocumentCount();
		int totalPage=0;
		if(total%rows==0){
			 totalPage=total/rows;
		}else{
			 totalPage=total/rows+1;
		}
		int startRows=rows*(page-1);
		String json="{\"page\":"+page+","
				+ "\"total\":"+totalPage+","
				+ "\"records\":"+total+","
				+ "\"rows\":[";
		List<Document> documentlist=documentService.getDocumentList(startRows,rows);
		int i=1;
		for(Document document:documentlist){
			i++;
			json+= "{\"id\":"+i+",\"cell\":[\""+document.getName()+"\",\""+document.getDescripion()+"\",\""+document.getSize()+"\",\""+document.getUploader()+"\",\""+document.getTime()+"\",\""+document.getId()+"\",\""+document.getDownloadCount()+"\"]},";
		}
		if(total!=0){
			 json = json.substring(0,json.length()-1);
			}
		 json+="],";
		 json+="\"userdata\":{\"amount\":200,\"tax\":342,\"total\":3564,\"name\":\"Totals\"}}";
		return json;
	}
	
	
	@RequestMapping(value="/upload",method=RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public String upload(@RequestParam("files") MultipartFile[] files,HttpServletRequest request){
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		documentService.saveFiles(files,username);
		return "{\"success\":\"true\"}";
		
	}
	@RequestMapping(value="/download/{id}",method=RequestMethod.GET,produces="text/html;charset=UTF-8")
	public String download(@PathVariable("id") int id,HttpServletResponse response) {

		String filePlace=documentService.getSavePlace(id);
		File a = new File(filePlace);
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/x-download");
		String filename=a.getName();
		String newFileName=filename;
		try {
		    newFileName = new String(filename.getBytes("utf-8"), "ISO8859-1");
		} catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
		response.setHeader("Content-Disposition", "attachment;fileName=" +newFileName);
		
		try{
			InputStream inputStream = new FileInputStream(a);

			OutputStream os = response.getOutputStream();
			byte[] b = new byte[2048];
			int length;
			while ((length = inputStream.read(b)) > 0) {
				os.write(b, 0, length);
			}
			os.close();
			inputStream.close();
			
		}catch(Exception e){
			
		}
		return null;
	}
	@RequestMapping(value="/downloadcountadd",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String downloadCountAdd(HttpServletRequest request,HttpServletResponse response){
		int documentid=Integer.parseInt(request.getParameter("documentid"));
		documentService.downloadCountAdd(documentid);
		return  "{\"success\":\"true\"}";
	}
	@RequestMapping(value="/editDescription",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String  editDescription(HttpServletRequest request,HttpServletResponse response){
		int id=Integer.parseInt(request.getParameter("id"));
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		String documentUploader=documentService.getUploaderById(id);
		if(username.equals(documentUploader)){
			String description=request.getParameter("description");
		    documentService.updateDescription(id, description);
		    return  "success";
		}
        return "抱歉，只有上传者才有权限修改哦";
	}
	@RequestMapping(value="/getBootStrapTableJson",produces="text/html;charset=UTF-8")
	public @ResponseBody String bootstrapTableJson(HttpServletRequest request,HttpServletResponse response){
		int page=Integer.parseInt(request.getParameter("pageNumber"));
		int rows=Integer.parseInt(request.getParameter("limit"));
		int total=documentService.getDocumentCount();
		int totalPage=0;
		if(total%rows==0){
			totalPage=total/rows;
		}else{
			totalPage=total/rows+1;
		}
		int startRows=rows*(page-1);
		List<Document> documentlist=documentService.getDocumentList(startRows,rows);
		String json="{\"total\":"+total+",\"rows\":[";
		int i=1;
		for(Document document:documentlist){
			i++;
			json+="{\"name\":\""+document.getName()+"\",\"description\":\""+document.getDescripion()+"\",\"size\":\""+document.getSize()+"\",\"uploader\":\""+document.getUploader()+"\",\"time\":\""+document.getTime()+"\",\"operation\":\""+document.getId()+"\",\"downloadcount\":\""+document.getDownloadCount()+"\"},";
		}
      /* String json="[{\"id\":\"1\",\"name\":\"Joseph\",\"price\":\"male\"}," +
			   "{\"id\":\"1\",\"name\":\"Joseph\",\"price\":\"male\"}," +
			   "{\"id\":\"1\",\"name\":\"Joseph\",\"price\":\"male\"}," +
			   "{\"id\":\"1\",\"name\":\"Joseph\",\"price\":\"male\"},"+
			   "{\"id\":\"1\",\"name\":\"Joseph\",\"price\":\"male\"}]";*/
		if(total!=0){
			json = json.substring(0,json.length()-1);
		}
		json+="]}";
       return json;
	}
}
