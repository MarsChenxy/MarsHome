package com.mars.controllers;

import com.mars.model.DrawGuessRoom;
import com.mars.service.DrawGuessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping("/drawguess")
public class DrawGuessController {
    @Autowired
    DrawGuessService drawGuessService;
    @RequestMapping("/in")
    public @ResponseBody
    String menmberIn(HttpServletRequest request, HttpServletResponse response){
        String roomid=request.getParameter("roomid");
        String roomname=request.getParameter("roomname");
        String time=request.getParameter("time");
        int mapRoomCount=drawGuessService.getRoomCountFromId(roomid);
        if(mapRoomCount==0){
            drawGuessService.addNewRoom(roomid,roomname,1,time);
        }else{
            drawGuessService.addRoomMember(roomid);
        }
        return "success";
    }
    @RequestMapping(value="/getDrawGuessRoomList",produces="text/html;charset=UTF-8")
    public @ResponseBody String getDrawGuessRoomList(HttpServletRequest request,HttpServletResponse response){
        int page=Integer.parseInt(request.getParameter("pageNumber"));
        int rows=Integer.parseInt(request.getParameter("limit"));
        int total=drawGuessService.getRoomCount();
        int totalPage=0;
        if(total%rows==0){
            totalPage=total/rows;
        }else{
            totalPage=total/rows+1;
        }
        int startRows=rows*(page-1);
        String json="{\"total\":"+total+",\"rows\":[";
        List<DrawGuessRoom> list=drawGuessService.getRoomList(startRows,rows);
        for(DrawGuessRoom drawGuessRoom:list){
            json+="{\"roomid\":\""+drawGuessRoom.getRoomid()+"\",\"roomname\":\""+drawGuessRoom.getRoomname()+"\",\"count\":\""+drawGuessRoom.getCount()+"\",\"time\":\""+drawGuessRoom.getCreatetime()+"\",\"operation\":\"\"},";
        }
        if(total!=0){
            json = json.substring(0,json.length()-1);
        }
        json+="]}";
        return json;

    }

}
