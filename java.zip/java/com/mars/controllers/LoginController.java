package com.mars.controllers;


import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mars.model.User;
import com.mars.service.UserService;


@Controller
@RequestMapping("/login")
public class LoginController{
  
  @Autowired
  UserService userService;
  @RequestMapping(value="/register" ,produces="text/html;charset=UTF-8")
  public @ResponseBody String register(HttpServletRequest request, HttpServletResponse response,HttpSession session,@CookieValue("userData") String userData) throws UnsupportedEncodingException{
	// JSONObject jsStr = JSONObject.fromObject(userData); 
	  JSONObject jsonData = JSONObject.parseObject(userData);
	  String username=jsonData.getString("username");
	  String password=jsonData.getString("password");
	  String sex=jsonData.getString("sex");
	  String head=jsonData.getString("head");
	  User user=new User();
	  user.setUsername(username);
	  System.out.println(username);
	  user.setPassword(password);
	  user.setSex(sex);
	  user.setHead(head);
	  int checkUsername=userService.checkUsername(username);
	  if(checkUsername==0){
		  userService.addUser(user);
		  return "success";
	  }else{
		  return "该用户已被注册，换个名字试试吧";
	  }
  }
  @RequestMapping(value="/checklogin",method=RequestMethod.POST,produces="text/html;charset=UTF-8")
  public  @ResponseBody String  checkLogin(HttpServletRequest request, HttpServletResponse response,@CookieValue("userloginData") String userloginData) throws IOException{
	  JSONObject jsonData = JSONObject.parseObject(userloginData);
	  String username=jsonData.getString("username");
	  String password=jsonData.getString("password");
	  int checkresult=userService.checkLogin(username, password);
	 if(checkresult==0){
		  return "用户名或密码输入错误";
	 }
	  String head=userService.selectHeadByName(username);
	  String sex=userService.selectSexByName(username);
	  HttpSession session = request.getSession();
	  session.setAttribute("username", username);
	  session.setAttribute("head", head);
	  session.setAttribute("sex", sex);
	  return "checked/"+username+"/"+head+"/"+sex;
	  
  }
}
