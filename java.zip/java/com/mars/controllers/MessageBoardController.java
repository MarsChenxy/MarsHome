package com.mars.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mars.model.Message;
import com.mars.service.MessageService;

@Controller
@RequestMapping("/chatroom")
public class MessageBoardController {
    @Autowired
    MessageService messageService;

    @RequestMapping(value = "/addMessage", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
    public @ResponseBody
    void addMessage(HttpServletRequest request) {
        String username = request.getParameter("username");
        String head = request.getParameter("head");
        String message = request.getParameter("message");
        String time = request.getParameter("time");
        messageService.addMessage(username, head, message, time);
    }

    @RequestMapping(value = "/getMessageList", produces = "text/html;charset=UTF-8")
    public @ResponseBody
    String getMessageList() throws Exception {
        List<Message> messagelist = messageService.selectMessageList();
        String jsonlist = "[";
        for (Message message : messagelist) {
            jsonlist += "{\"username\":\"" + message.getUsername() + "\",\"head\":\"" + message.getHead() + "\",\"message\":\"" + message.getMessage() + "\",\"time\":\"" + message.getTime() + "\"},";
        }
        jsonlist = jsonlist.substring(0, jsonlist.length() - 1);
        jsonlist += "]";
        return jsonlist;

    }


}
