package com.mars.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/getpage")
public class PageController {
    @RequestMapping("/{pageName}")
    public String jsp(@PathVariable("pageName") String pageName) {
        return pageName;
    }

}
