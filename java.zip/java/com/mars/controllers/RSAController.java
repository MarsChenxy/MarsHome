package com.mars.controllers;

import com.mars.beanfactory.RSAUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;

@Controller
@RequestMapping("/rsa")
public class RSAController {
    @RequestMapping("/{message}")
    public void rsa(@PathVariable("message") String message)throws Exception{
        // TODO Auto-generated method stub
        HashMap<String, Object> map = RSAUtils.getKeys();
        //生成公钥和私钥
        RSAPublicKey publicKey = (RSAPublicKey) map.get("public");
        RSAPrivateKey privateKey = (RSAPrivateKey) map.get("private");


        String modulus = publicKey.getModulus().toString();
        //模
        modulus="126257991562935405343879698309204695807343958207371759509570097922483022243181522868590346850872190322362087286674452709138850969434301245316225649016664519277976982809639861564579261377734589707388222619614650354587945294255733311145103161476562959996102154444308440389237415394516107545837831692586040172047";

        String public_exponent = publicKey.getPublicExponent().toString();
        //公钥指数
        public_exponent="65537";
        //私钥指数
        String private_exponent = privateKey.getPrivateExponent().toString();
        private_exponent="40986599485808791197202200001958129046206611698152710431757691583392988666305856219071053439313759389478514534141004034162824883267692433191978587406038377854578510759457453056956284076476262135381621722776704489110048644552267145154634164499536361206438029029258942809169665860800177672434571828245096808673";
        //明文
        String ming = message;
        System.out.println("加密前的明文:"+message);
        //使用模和指数生成公钥和私钥
        RSAPublicKey pubKey = RSAUtils.getPublicKey(modulus, public_exponent);
        System.out.println("公钥:"+pubKey);
        RSAPrivateKey priKey = RSAUtils.getPrivateKey(modulus, private_exponent);
        System.out.println("私钥:"+priKey);
        //加密后的密文
        String mi = RSAUtils.encryptByPublicKey(ming, pubKey);
        System.out.println("加密后的密文:"+mi);
        //7418加密后:B060A6B3689E7AAE68491F855A945E7D5A7843A26FAD97B2C8B08248166D13CEA594833C0E99C9B26C15796CD999089F980B4FF5F7AD1E3DF45D30B07B3A4DE6385701C83BB32150955F9D20EE0F11EAE08BD5AD2FFA80EB9516C5196E56A3138D17CC9784B0CBD2EFB91B86FEA1FE4DFE633BC99692A9BD8E431BB82D090CC7
        //解密后的明文
        ming = RSAUtils.decryptByPrivateKey(mi, priKey);
        System.out.println("解密后的明文:"+ming);

    }
}
