package com.mars.controllers;

import com.mars.beanfactory.TransStringTool;
import com.mars.model.RSAUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
@RequestMapping("/sign")
public class SignController {
    static String publicKey;
    static String privateKey;
    static {
        try {
            Map<String, Object> keyMap = RSAUtils.genKeyPair();
            publicKey = RSAUtils.getPublicKey(keyMap);
            //publicKey="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCv1oj/r0hgN2gWh2dkPX0/tTBMzb+gFZGp5dmuM/M+1x7TV+1k/bEjDrJtQD832JoIpzqG46EOasc4xlWAtheNtD79dEuIC1UCy5wL3E9LaQxgXLKibEy/hxR+gqqvW93IAXljrciiYO8SB3oO8gYrL3eSKFFsRC/wl6q2mJdH7QIDAQAB";
            //publicKey="MIGJAoGBAL7fQrL/SHmsMP6W8XVvcVt2tq2gZ3gJ8rl59tVDx6pcUgfQsYaumJ0zWrjHpWiTGAmOr/LanStmhLCgoNF9lMGuQU4J4bek5Et50wmqWpXt3DL6on1PVZzUq5YYbZEpH1JKE3QVk7PsU9NZl4fERQyG6oeRoHQp9oIMcbQsguSvAgMBAAE=";
            privateKey = RSAUtils.getPrivateKey(keyMap);
           // privateKey="MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAK/WiP+vSGA3aBaHZ2Q9fT+1MEzNv6AVkanl2a4z8z7XHtNX7WT9sSMOsm1APzfYmginOobjoQ5qxzjGVYC2F420Pv10S4gLVQLLnAvcT0tpDGBcsqJsTL+HFH6Cqq9b3cgBeWOtyKJg7xIHeg7yBisvd5IoUWxEL/CXqraYl0ftAgMBAAECgYEAgy0d2Pjvmm/bI+txk1NX674EwVdAnHFa0I9bXFz/GyMqqOnQfOXRTuD49Q3X25aoGsp+nACWtwWrh8xWHwY4/MzeurxMNJY4QA+Lud2qcJZdlspYeiH6F7h6bc4GkmAZ0mDh949Jah/EK97sSkiLQNbq4iaLuQ4GE0tNhaVGHIECQQDoQD0dpsrye/A8Fw3smv2TfKS98N/1uLldGbu2//QpEA1JEeH6TF6KQ0Zp+/FKDg3f4cWqZwlfksYP+k5QLushAkEAwdGLaVOMNyqA4cJniWYomd+xcQHg/MzZJVrxKhfsbiopECD2jKeDai/uY013P0/L/iYh8CncYMMW/fVs1t+vTQJBAJvbYCgh4lfPrGvm3MVHTZxILRX6K5FuoZZEyqAILAXSa9f5VDjwPxFyDDLbjBUyUUVI8alk8/lbOedHBn7wvYECQAbigqlDJn/vKpTaawMedeLBZ3Q0NOHGBRCmolp0bxmatcq04Q0uBiUHfthYMBw3oW9tu1bkpcdqJq7uwOcBGyECQAuY725mpqlyUgrIiM5tGaxs+BStcwjuIfBygMH2Q4s2FDRS+aNdHxFnZG5+R4oCwyAb8e1conpwztqp02vLpHY=";
          //  privateKey="MIICXwIBAAKBgQC+30Ky/0h5rDD+lvF1b3FbdratoGd4CfK5efbVQ8eqXFIH0LGGrpidM1q4x6VokxgJjq/y2p0rZoSwoKDRfZTBrkFOCeG3pORLedMJqlqV7dwy+qJ9T1Wc1KuWGG2RKR9SShN0FZOz7FPTWZeHxEUMhuqHkaB0KfaCDHG0LILkrwIDAQABAoGABkJB6KawVLUNwjtm3Yfy+qHQ6a6Z1fjViblzG5kmYfK3CeSQ/a6Z+IWnkumRBfXU0vNn15nNj4/ECBqsQvHsOb7/WkCycUMyrsqwHjfrBKmOuRMC0WEz9SVBeC/Zj/ZSu/ewJhBUZMx+7Ylmft3YCIYoZsdV4nIfZXGM0GoEQ+ECRQD/c29kBY/ly5VGxmwNkdtulRVAEeN5ZF7aQPapZYzhKp2p/vmMoEGEiWSKd+TG+xFksUggF/5lB6jhOJQpCgY+BHpFfwI9AL9ISkjUyyZQYyaILj2+BrsxK4QyEYiOadnukGSitZl//UxzkFd1KQhtmyj0v9E4XsPH1WiYCHbm3nPY0QJELvT6Qemf1P8CVrs8u5XXP1GaUWe4Z+UiZn5QmTz4k59w0gHzv3zp7kIPQEDfxg/614abGoMumUW6LoRm/9A+64GJNGMCPHaXoza0d58xh8eD9udgwVudiJVVVXmMkiQDvJIoLt8Ucz7LB1qx0Nbg3anu1F4qzNYlNzK5z8WoLZM1gQJEGcFl+LBTQTWwxo8anoEdcP+UTlJr5TOMPjOnbjLhAGnI2KjoXOejechxf8U6B89Rw50FbsS9qXW6ty5zG6dfgFytG9g=";
            System.err.println("公钥: \n\r" + publicKey);
            System.err.println("私钥： \n\r" + privateKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @RequestMapping("/{message}")
    public void sign(@PathVariable("message") String message)throws Exception{
        Map<String, Object> keyMap = RSAUtils.genKeyPair();
        publicKey = RSAUtils.getPublicKey(keyMap);
        privateKey = RSAUtils.getPrivateKey(keyMap);
        String source=message;
        System.err.println("公钥加密——私钥解密");
        System.out.println("\r加密前文字：\r\n" + source);
        byte[] data = source.getBytes();

        //公钥加密
        byte[] encodedData = RSAUtils.encryptByPublicKey(data, publicKey);
        System.out.println("加密后文字：\r\n" + new String(encodedData));
        String hex = TransStringTool.byte2HexStr(encodedData,encodedData.length);
        System.out.println("string转hex(16进制)："+hex);
        String hex2str=TransStringTool.hexStr2Str(hex);
        System.out.println("hex(16进制)转string:"+hex2str);

        //私钥解密
        byte[] decodedData = RSAUtils.decryptByPrivateKey(encodedData, privateKey);
        String target = new String(decodedData);
        System.out.println("解密后文字: \r\n" + target);

        System.err.println("私钥加密——公钥解密");

        System.out.println("原文字：\r\n" + source);
         data = source.getBytes();
         /*
        //私钥加密
         encodedData = RSAUtils.encryptByPrivateKey(data, privateKey);
        System.out.println("加密后：\r\n" + new String(encodedData));
        //公钥解密
         decodedData = RSAUtils.decryptByPublicKey(encodedData, publicKey);
         target = new String(decodedData);
        System.out.println("解密后: \r\n" + target);
        */

        System.err.println("私钥签名——公钥验证签名");
        //String sign = RSAUtils.sign(encodedData, privateKey);
        String sign = RSAUtils.sign(data, privateKey);
        System.out.println("签名:" + sign);
        byte[] signbyte = sign.getBytes();
        String signhex = TransStringTool.byte2HexStr(signbyte,signbyte.length);
        System.out.println("string转hex(16进制)："+signhex);
        String signhexNoBlank=signhex.replace(" ","");
        System.out.println("hex去除空格："+signhexNoBlank);
        String signstr=TransStringTool.hexStr2Str(signhex);
        System.out.println("hex(16进制)转string:"+signstr);
        boolean status = RSAUtils.verify(data, publicKey, sign);
        System.out.println("验证结果:" + status);
    }
}
