package com.mars.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mars.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;
	@RequestMapping("/update")
	public @ResponseBody String update(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		String username=request.getParameter("username");
		String oldpassword = request.getParameter("oldpassword");
		String newpassword = request.getParameter("newpassword");
		String head = request.getParameter("head");
		String sex = request.getParameter("sex");
		if(userService.checkLogin(username, oldpassword)==1){
			userService.updateUser(username, newpassword, head, sex);
			session.setAttribute("username", username);
			session.setAttribute("head", head);
			session.setAttribute("sex", sex);
			return "success";
		}else{
			return "The password is wrong";
		}
		
	}

}
