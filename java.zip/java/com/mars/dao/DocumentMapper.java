package com.mars.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.mars.model.Document;

public interface DocumentMapper {
	public List<Document> getDocumentList(@Param("startRows") int startRows, @Param("rows") int rows);
	public int getDocumentCount();
	public void saveDocument(Document document);
	public String getSavePlaceById(@Param("id") int id);
	public void downloadCountAdd(@Param("id") int id);
	public String getDescriptionById(@Param("id") int id);
	public void updateDescription(@Param("id") int id, @Param("description") String description);
    public String getUploaderById(@Param("id") int id);
}
