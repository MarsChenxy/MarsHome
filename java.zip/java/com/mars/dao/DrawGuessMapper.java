package com.mars.dao;

import com.mars.model.DrawGuessRoom;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DrawGuessMapper {
    public void addNewRoom(@Param("roomid") String roomid,
                           @Param("roomname") String roomname,
                           @Param("count") int count,
                           @Param("createtime") String createtime);
    public void addRoomMember(@Param("roomid") String roomid);
    public void delRoomMember(@Param("roomid") String roomid);
    public void delRoom(@Param("roomid") String roomid);
    public List<DrawGuessRoom> getRoomList(@Param("startRows") int startRows, @Param("rows") int rows);
    public int getRoomCount();
    public int getRoomMemberCount(@Param("roomid") String roomid);
    public int getRoomCountFromId(@Param("roomid") String roomid);
}
