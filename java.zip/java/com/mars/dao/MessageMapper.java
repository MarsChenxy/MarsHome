package com.mars.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.mars.model.Message;


public interface MessageMapper {
	public void addMessage(@Param("username") String username,
                           @Param("head") String head,
                           @Param("message") String message,
                           @Param("time") String time);
	public List<Message> selectMessageList()throws Exception;

}
