package com.mars.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.mars.model.Room;

public interface RoomMapper {
	public void addNewRoom(@Param("roomid") String roomid,
                           @Param("roomname") String roomname,
                           @Param("count") int count,
                           @Param("createtime") String createtime);
	public void addRoomMember(@Param("roomid") String roomid);
	public void delRoomMember(@Param("roomid") String roomid);
	public void delRoom(@Param("roomid") String roomid);
	public List <Room> getRoomList(@Param("startRows") int startRows, @Param("rows") int rows);
	public int getRoomCount();
	public int getRoomMemberCount(@Param("roomid") String roomid);
	public int getRoomCountFromId(@Param("roomid") String roomid);
	}
