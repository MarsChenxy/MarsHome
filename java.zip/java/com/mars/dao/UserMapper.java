package com.mars.dao;

import org.apache.ibatis.annotations.Param;

import com.mars.model.User;


public interface UserMapper {
	public void addUser(@Param("user") User user);
	public int checkUsername(@Param("username") String username);
	public int checkLogin(@Param("username") String username, @Param("password") String password);
	public String selectHeadByName(@Param("username") String username);
	public String selectSexByName(@Param("username") String username);
	public void updateUser(@Param("username") String username,
                           @Param("password") String password,
                           @Param("head") String head,
                           @Param("sex") String sex);
}
