package com.mars.intercepter;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginInterceptor implements HandlerInterceptor{
	/*HandlerInterceptor是SpringMvc提供的借口，实现这个借口或者继承此类可以方便地实现自定义拦截器效果*/

    //最后执行，可用于释放资源   返回处理，已经渲染了页面
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

    //生成视图之前执行  后处理已经处理并返回ModelAndView，但未进行渲染  可以更改ModelAndView内容
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

    //Action之前执行  预处理
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws Exception {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		StringBuffer url=request.getRequestURL();
		String contestpath=request.getContextPath();
		if((url.indexOf("checklogin")!=-1)||(username!=null)||(url.indexOf("register")!=-1)){
			return true;
		}else{
				response.sendRedirect(contestpath);
				}
		return false;
		/*HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		if(username!=null){
			return true;
		}else{
			response.sendRedirect("http://localhost:8080/MarsHome");
		}
		return false;*/
	}

}
