package com.mars.model;

public class Document {
	private String name;
	private String description;
	private String uploader;
	private String time;
	private String size;
	private String saveplace;
	private int id;
	private int downloadcount;
	public String getName(){
		return name;
	}
	public String getDescripion(){
		return description;
	}
	public String getUploader(){
		return uploader;
	}
	public String getTime(){
		return time;
	}
	public String getSize(){
		return size;
	}
	public String getSaveplace(){
		return saveplace;
	}
	public int getId(){
		return id;
	}
	public int getDownloadCount(){
		return downloadcount;
	}
	public void setName(String name){
		this.name=name;
	}
	public void setDescripion(String description){
		this.description=description;
	}
	public void setUploader(String uploader){
		this.uploader=uploader;
	}
	public void setTime(String time){
		this.time=time;
	}
    public void setSize(String size){
    	this.size=size;
    }
    public void setId(int id){
    	this.id=id;
    }
    public void setSavePlace(String saveplace){
    	this.saveplace=saveplace;
    }
    public void setDownloadCount(int  downloadcount){
    	this.downloadcount=downloadcount;
    }
    
}
