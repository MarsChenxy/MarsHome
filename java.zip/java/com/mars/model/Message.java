package com.mars.model;

public class Message {
	private String username;
	private String head;
	private String message;
	private String time;
	public String getUsername(){
		return username;
	}
	public String getHead(){
		return head;
	}
	public String getMessage(){
		return message;
	}
	public String getTime(){
		return time;
	}
	public void setUsername(String username){
		this.username=username;
	}
	public void setHead(String head){
		this.head=head;
	}
	public void setMessage(String message){
		this.message=message;
	}
	public void setTime(String time){
		this.time=time;
	}

}
