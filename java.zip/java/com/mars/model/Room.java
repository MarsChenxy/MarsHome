package com.mars.model;

public class Room {
	private String roomid;
	private String roomname;
	private int    count;
	private String createtime;
	
	public void setRoomid(String roomid){
		this.roomid=roomid;
	}
	public void setRoomname(String roomname){
		this.roomname=roomname;
	}
	public void setCount(int count){
		this.count=count;
	}
	public void setCreatetime(String createtime){
		this.createtime=createtime;
	}
	public String getRoomid(){
		return roomid;
	}
	public String getRoomname(){
		return roomname;
	}
    public int getCount(){
    	return count;
    }
    public String getCreatetime(){
    	return createtime;
    }
}
