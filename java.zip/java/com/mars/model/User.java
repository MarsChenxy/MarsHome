package com.mars.model;

public class User {
	private String username;
	private String password;
	private String sex;
	private String head;
	
	public String getUsername(){
		return username;
	}
	public String getPassword(){
		return password;
	}
	public String getSex(){
		return sex;
	}
	public String getHead(){
		return head;
	}
	public void setUsername(String username){
		this.username=username;
	}
	public void setPassword(String password){
		this.password=password;
	}
	public void setSex(String sex){
		this.sex=sex;
	}
	public void setHead(String head){
		this.head=head;
	}

}
