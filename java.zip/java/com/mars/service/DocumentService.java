package com.mars.service;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.mars.dao.DocumentMapper;
import com.mars.model.Document;

@Service
public class DocumentService {
	@Autowired
	DocumentMapper documentMapper;
	public List<Document> getDocumentList(int startRows,int rows){
		return documentMapper.getDocumentList(startRows,rows);
	}
	public int getDocumentCount(){
		return documentMapper.getDocumentCount();
	}
	public void saveFiles(MultipartFile[] files,String username){
		String path = "/documents";
		for(MultipartFile file:files){
			if (file != null) {
				try{
				 String myFileName = file.getOriginalFilename();
				 if (myFileName.trim() != "") {
					 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					 SimpleDateFormat dateformat2 = new SimpleDateFormat("yyyyMMddHHmmss");
	                	String dateStr = dateformat.format(System.currentTimeMillis());
	                	String dateStr2 = dateformat2.format(System.currentTimeMillis());
	                    String fileName = file.getOriginalFilename();
	                    String fileName_ = fileName.substring(0, fileName.lastIndexOf(".")) + "_" + dateStr2 + fileName.substring(fileName.lastIndexOf("."));
	                    File localFile = new File(path+File.separator + fileName_);
	                    if(!localFile.exists()){
	                    	localFile.mkdirs();      							
	                    }
	                    file.transferTo(localFile);
	                    Document document=new Document();
	                    document.setName(fileName);
	                    document.setDescripion("");
	                    String size=getSize(localFile.length());
	                    document.setSize(size);
	                    document.setTime(dateStr);
	                    document.setUploader(username);
	                    document.setSavePlace(path+File.separator + fileName_);
	                    document.setDownloadCount(0);
	                    documentMapper.saveDocument(document);
				 }
				 }catch (Exception e) {
						e.printStackTrace();
						continue;
					}
					
				 }
			}
	}
	public static String getSize(long size) {
        double size_ = 0;
        DecimalFormat df = new DecimalFormat("0.00");// 浠b涓哄崟浣嶄繚鐣欎袱浣嶅皬鏁�
        
        if(size>0&&size<1024){
        	return df.format(size) +" byte";
        }else if(size<1024*1024){
        	size_ = (size + 0.0) / (1024);
        	return df.format(size_) +" kb";
        }else{
        	size_ = (size + 0.0) / (1024 * 1024);
        	return df.format(size_) +" Mb";
        }
    }
	public String getSavePlace(int id){
		return documentMapper.getSavePlaceById(id);
	}
	public void downloadCountAdd(int id){
		documentMapper.downloadCountAdd(id);
	}
	public String getDescriptionById(int id){
		return documentMapper.getDescriptionById(id);
	}
	public void updateDescription(int id,String description){
		documentMapper.updateDescription(id, description);
	}
	public String getUploaderById(int id){
		return documentMapper.getUploaderById(id);
	}
}
