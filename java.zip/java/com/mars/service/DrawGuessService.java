package com.mars.service;

import com.mars.dao.DrawGuessMapper;
import com.mars.model.DrawGuessRoom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DrawGuessService {
    @Autowired
    DrawGuessMapper drawGuessMapper;
    public void addNewRoom(String roomid,String roomname,int count,String createtime){
        drawGuessMapper.addNewRoom(roomid,roomname,count,createtime);
    }
    public List<DrawGuessRoom> getRoomList(int startRows, int rows){
        return drawGuessMapper.getRoomList(startRows,rows);
    }
    public int  getRoomCount(){
        return drawGuessMapper.getRoomCount();
    }
    public void addRoomMember(String roomid){
        drawGuessMapper.addRoomMember(roomid);
    }
    public void delRoomMember(String roomid){
        drawGuessMapper.delRoomMember(roomid);
    }
    public void delRoom(String roomid){
        drawGuessMapper.delRoom(roomid);
    }
    public int getRoomMemberCount(String roomid){
        return drawGuessMapper.getRoomMemberCount(roomid);
    }
    public int getRoomCountFromId(String roomid){
        return drawGuessMapper.getRoomCountFromId(roomid);
    }

}
