package com.mars.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mars.dao.MessageMapper;
import com.mars.model.Message;

@Service
public class MessageService {
	@Autowired
	MessageMapper messageMapper;
	public void addMessage(String username,String head,String message,String time){
		messageMapper.addMessage(username,head,message,time);
	}
	public List<Message> selectMessageList() throws Exception{
		return messageMapper.selectMessageList();
	}

}
