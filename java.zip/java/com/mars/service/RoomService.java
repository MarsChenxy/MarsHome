package com.mars.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mars.dao.RoomMapper;
import com.mars.model.Room;

@Service
public class RoomService {
	@Autowired
	RoomMapper roomMapper;
	public void addNewRoom(String roomid,String roomname,int count,String createtime){
		roomMapper.addNewRoom(roomid,roomname,count,createtime);
	}
    public List <Room> getRoomList(int startRows,int rows){
    	return roomMapper.getRoomList(startRows,rows);
    }
    public int  getRoomCount(){
    	return roomMapper.getRoomCount();
    }
    public void addRoomMember(String roomid){
    	roomMapper.addRoomMember(roomid);
    }
    public void delRoomMember(String roomid){
    	roomMapper.delRoomMember(roomid);
    }
    public void delRoom(String roomid){
    	roomMapper.delRoom(roomid);
    }
    public int getRoomMemberCount(String roomid){
    	return roomMapper.getRoomMemberCount(roomid);
    }
    public int getRoomCountFromId(String roomid){
    	return roomMapper.getRoomCountFromId(roomid);
    }
}
