package com.mars.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mars.dao.UserMapper;
import com.mars.model.User;

@Service
public class UserService {
	@Autowired
	UserMapper userMapper;
   public void addUser(User user){
	   userMapper.addUser(user);	   
   }
   public int checkUsername(String username){
	   return userMapper.checkUsername(username);
   }
   public int checkLogin(String username,String password){
	   return userMapper.checkLogin(username, password);
   }
   public String selectHeadByName(String username){
	   return userMapper.selectHeadByName(username);
   }
   public String selectSexByName(String username){
	   return userMapper.selectSexByName(username);
   }
   public void updateUser(String username,String password,String head,String sex){
	   userMapper.updateUser(username, password, head, sex);
   }
}
