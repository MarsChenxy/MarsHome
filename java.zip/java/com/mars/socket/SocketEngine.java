package com.mars.socket;

import javax.servlet.http.HttpServlet;

public class SocketEngine extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public  void init() {  
		System.out.println("SocketEngine Started");
		SocketService ss=new SocketService();
        Thread t=new Thread(ss);
        t.start();
	}
}
