package com.mars.websocket;

import com.alibaba.fastjson.JSONObject;
import com.mars.beanfactory.SpringBeanFactoryUtils;
import com.mars.service.RoomService;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.concurrent.CopyOnWriteArraySet;
@Component
@ServerEndpoint("/websocket/{roomid}/{username}")
public class WebSocket{
	private static HashMap<String, String> hashMap = new HashMap<String, String>();
	private static CopyOnWriteArraySet<WebSocket> webSocket=new CopyOnWriteArraySet();
	private  String room;
	private Session session;
	public WebSocket(){
	}
	
	
	@OnOpen
	public void onOpen(Session session,@PathParam("username")String  username,@PathParam("roomid")String  roomid) throws UnsupportedEncodingException{
		 username = new String(username.getBytes("iso-8859-1"), "utf-8");
		
		this.session = session;
		this.room=roomid;
        webSocket.add(this);
        String count=hashMap.get(roomid);
        if(count==null){
        	count="1";
        hashMap.put(roomid,count);

        }else{
        	int countInt=Integer.parseInt(count);
        	countInt++;
        	count= Integer.toString(countInt);
        	hashMap.put(roomid, count);
        }
      
        String message = String.format("[%s %s]",username,"加入聊天室");
         message="{\"text\":\""+message+"\",\"count\":\""+count+"\",\"username\":\"系统提示\",\"head\":\"system\",\"roomid\":\""+roomid+"\"}";
        broadcast(message,roomid);
	}
	
	
	
	@OnMessage
	public void onMessage(String message,Session session,@PathParam("roomid")String  roomid){
		JSONObject jsonData = JSONObject.parseObject(message);
		String username=jsonData.getString("username");
		String head=jsonData.getString("head");
		String text=jsonData.getString("text");
		 String count=hashMap.get(roomid);
		String onmessage="{\"text\":\""+filter(text)+"\",\"count\":\""+count+"\",\"username\":\""+username+"\",\"head\":\""+head+"\",\"roomid\":\""+roomid+"\"}";
		if(text!=null){
		broadcast(onmessage,roomid);
		}
	}
	
	
	@OnClose
	public void  onClose(@PathParam("username")String  username,@PathParam("roomid")String  roomid) throws UnsupportedEncodingException{
		username = new String(username.getBytes("iso-8859-1"), "utf-8");
		String count=hashMap.get(roomid);
		 RoomService roomService=(RoomService)SpringBeanFactoryUtils.getBean("RoomService");		 
		int countInt=Integer.parseInt(count);
		if(countInt<=1){
			hashMap.remove(roomid);
			roomService.delRoom(roomid);
		}else{
			countInt--;
			count= Integer.toString(countInt);
			hashMap.put(roomid, count);
			roomService.delRoomMember(roomid);
		}
		webSocket.remove(this);
		String message=String.format("[%s,%s]", username,"离开了");
		message="{\"text\":\""+message+"\",\"count\":\""+count+"\",\"username\":\"系统提示\",\"head\":\"system\",\"roomid\":\""+roomid+"\"}";
		broadcast(message,roomid);
	}
	private void broadcast(String info,String roomid){
		for (WebSocket w : webSocket) {
			String wr = w.room;
			boolean b = (wr.equals(roomid));
			if (w.room.equals(roomid)) {

				try {
					synchronized (WebSocket.class) {
						w.session.getBasicRemote().sendText(info);
					}
				} catch (IOException e) {
					System.out.println("客户端" + w.room + "发送消息失败");
					webSocket.remove(w);
					try {
						w.session.close();
					} catch (IOException e1) {
					}
					String message = String.format("[%s,%s]", w.room, "已经断开连接");
					broadcast(message, roomid);
				}

			}
		}
	}
	public static String filter(String message){
		if(message==null){
			return null;
		}
		return message;
	}

}
