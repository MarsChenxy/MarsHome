package com.mars.websocket;

import com.mars.beanfactory.SpringBeanFactoryUtils;
import com.mars.service.DrawGuessService;
import com.mars.service.UserService;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

@Component
@ServerEndpoint("/websocketDrawGuess/{roomid}/{username}")
public class WebSocketDrawGuess {
    private static HashMap<String, String> hashMap = new HashMap<String, String>();
    private static HashMap<String, String> userRoomMap = new HashMap<String, String>();
    private static CopyOnWriteArraySet<WebSocketDrawGuess> webSocketDrawGuesses =new CopyOnWriteArraySet();
    private Session session;
    private  String roomid;
    private UserService usesrservice;
    public WebSocketDrawGuess(){

    }
    @OnOpen
    public void onOpen(Session session,@PathParam("username")String  username,@PathParam("roomid")String  roomid) throws UnsupportedEncodingException {

        DrawGuessService drawGuessService;
        this.session = session;
        this.roomid=roomid;
        webSocketDrawGuesses.add(this);
        String count=hashMap.get(roomid);
        userRoomMap.put(username,roomid);
        String json="{\"action\":in,\"users\":[";
        String roomUserJson="[";
        Set<String> userRoomMapKey=userRoomMap.keySet();

        for(int i=0;i<userRoomMap.size();i++){
            if(userRoomMap.get(userRoomMapKey.toArray()[i])==roomid){
                String room=userRoomMapKey.toArray()[i]+"";
                String name=userRoomMapKey.toArray()[i]+"";
                String  head=usesrservice.selectHeadByName(name);
                roomUserJson+="{\"name\":\""+name+"\",\"head\":\""+head+"\",\"room\":\""+room+"\"},";
            }
        }
        roomUserJson= roomUserJson.substring(0,roomUserJson.length()-1);
        roomUserJson+="]";
        if(count==null){
            count="1";
            hashMap.put(roomid,count);

        }else{
            int countInt=Integer.parseInt(count);
            countInt++;
            count= Integer.toString(countInt);
            hashMap.put(roomid, count);

        }
        Set<String> keys=hashMap.keySet();
        for(int i=0;i<keys.size();i++){
             System.out.println(hashMap.get(keys.toArray()[i]));
        }
    }
    @OnMessage
    public void onMessage(String message,Session session,@PathParam("roomid")String  roomid){
        broadcast(message,roomid);
    }
    @OnClose
    public void  onClose( @PathParam("roomid")String  roomid,@PathParam("username")String  username) throws UnsupportedEncodingException{

        String count=hashMap.get(roomid);
        int countInt=Integer.parseInt(count);
        DrawGuessService drawGuessService=(DrawGuessService) SpringBeanFactoryUtils.getBean("DrawGuessService");
        if(countInt<=1){
            hashMap.remove(roomid);
            drawGuessService.delRoom(roomid);
        }else{
            countInt--;
            count= Integer.toString(countInt);
            hashMap.put(roomid, count);
            drawGuessService.delRoomMember(roomid);
        }
        userRoomMap.remove(username);
        webSocketDrawGuesses.remove(this);

    }
    private void broadcast(String info,String roomid){
        for (WebSocketDrawGuess w : webSocketDrawGuesses) {
            if (w.roomid.equals(roomid)) {
                try {
                    synchronized (WebSocket.class) {
                        w.session.getBasicRemote().sendText(info);
                    }
                } catch (IOException e) {
                    System.out.println("发送消息失败");
                    webSocketDrawGuesses.remove(w);
                    try {
                        w.session.close();
                    } catch (IOException e1) {
                    }
                    //String message = String.format("已经断开连接");
                    // broadcast(message);
                }

            }
            }

            }


    }

